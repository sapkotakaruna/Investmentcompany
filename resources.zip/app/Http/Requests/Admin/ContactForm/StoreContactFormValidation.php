<?php

namespace App\Http\Requests\Admin\ContactForm;

use App\Models\ContactForm;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Str;

class StoreContactFormValidation extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    //    public function authorize()
    //    {
    //        return true;
    //    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'name'               => ['required', 'max:150', 'string'],
            'email'              => ['required', 'max:150'],
            'subject'            => ['required', 'max:150'],
            'message'            => ['required', 'max:150'],
            'status'             => ['nullable'],
        ];
    }
    public function prepareForValidation()
    {
        $this->merge([
            'status' => $this->status ? 1 : 0,
        ]);
    }
}
