<div class="mt-10 max-w-6xl mx-auto">
    <h2 class="text-4xl text-center mb-8">Associate Partner</h2>
    <div class="overflow-hidden relative">
        <div class="flex animate-scroll">
            @forelse ($data['assopartner'] as $associate)
                <img src="{{ $associate->image_path_withAsset() }}" alt="{{ $associate->title }}"
                    class="w-40 h-40 md:w-60 md:h-60  object-contain mx-4">
            @empty
                <p> No Data Found</p>
            @endforelse
        </div>
    </div>
</div>
