<div class="mt-10 max-w-6xl mx-auto">
    <h2 class="text-4xl text-center mb-8">Our Client</h2>
    <div class="overflow-hidden relative">
        <div class="flex animate-scroll">
            @forelse ($data['_partners'] as $partner)
                <img src="{{ $partner->image_path_withAsset() }}" alt="{{ $partner->title }}"
                    class="w-40 h-40 md:w-60 md:h-60  object-contain mx-4">
            @empty
                <p> No Data Found</p>
            @endforelse
        </div>
    </div>
</div>
