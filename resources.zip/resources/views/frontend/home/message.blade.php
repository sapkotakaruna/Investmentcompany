@forelse ($data['_message'] as $message)
    <div class="max-w-6xl mx-auto mt-10 p-4 lg:p-0">
        <div class="flex flex-col lg:flex-row md:items-center gap-6 bg-white shadow-lg rounded-lg overflow-hidden">
            
            <div class="md:w-1/2 w-full">
                <img src="{{ $message->image_path() }}" 
                     alt="{{ $message['name'] }}" 
                     class="w-full h-64 md:h-full object-cover transition-transform duration-300 hover:scale-105">
            </div>

            <div class="flex flex-col justify-center gap-4 p-6 md:w-1/2 w-full">
                <h2 class="text-4xl md:text-5xl font-bold text-blue-900">{{ $message->name }}</h2>
                <p class="text-lg text-gray-700 leading-relaxed">
                    {!! Str::limit(strip_tags($message->excerpt), 1000) !!}
                </p>
            </div>
            
        </div>
    </div>
@empty
    <p class="text-center text-gray-500 mt-10">No message found.</p>
@endforelse

