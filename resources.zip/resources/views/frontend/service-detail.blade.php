{{-- @extends('common.layout')

@section('content')
    <!-- Header Section -->
    <div class="relative h-60 mb-10">
        <div class="absolute inset-0 bg-[url('/image/10.jpg')] bg-cover bg-center"></div>
        <div class="absolute inset-0 bg-black opacity-50"></div>
        <div class="relative flex items-center justify-center h-full">
            <h1 class="font-bold text-[50px] text-white tracking-wider uppercase">{{ $_service->name }}</h1>
        </div>
    </div>

    <!-- Detail Content -->
    <div class="max-w-6xl mx-auto mt-8 p-4">
        <div class="flex flex-col lg:flex-row gap-12 items-start bg-white rounded-xl shadow-2xl p-8">

            <!-- Image Section -->
            <div class="lg:w-1/2">
                <div class="relative overflow-hidden rounded-xl">
                    @if (isset($_service->photo))
                        <img src="{{ $_service->image_path_withAsset() }}" alt="{{ $_service->name }}"
                            class="w-full h-[400px] object-cover transform hover:scale-105 transition-transform duration-500 ease-in-out">
                    @endif

                    <div class="absolute top-4 left-4 bg-blue-900 text-white px-4 py-2 rounded-full">
                        Featured Service
                    </div>
                </div>
            </div>

            <!-- Text Section -->
            <div class="lg:w-1/2 space-y-6">
                <div class="border-l-4 border-blue-900 pl-6">
                    <h2 class="text-4xl font-bold text-[#1a3c77] leading-tight">{{ $_service->name }}</h2>

                </div>

                <div class="space-y-4">
                    <p class="text-gray-700 leading-relaxed text-lg">
                        @if (!empty($_service->excerpt))
                            <p class="mb-0">{!! $_service->excerpt !!}</p>
                        @else
                            <p class="mb-0"></p>
                        @endif
                    </p>


                </div>
            </div>
        </div>
    </div>


    <!-- Related Services (List View) -->
    <div class="max-w-6xl mx-auto mt-16 px-4">
        <h2 class="text-2xl font-bold text-[#1a3c77] mb-4 border-b-2 border-blue-900 pb-2">
            Related Services
        </h2>

        <ul class="list-disc pl-6 space-y-2 text-[#1a3c77]">
            @forelse ($all_service as $service)
                <li>
                    <a href="{{ route('serviceDetail', $service->slug) }}" class="hover:underline">
                        {{ \Illuminate\Support\Str::limit($service->name, 50) }}
                    </a>
                </li>
            @empty
                <li class="text-gray-500">No related services found.</li>
            @endforelse
        </ul>
    </div>
@endsection --}}

@extends('common.layout')

@section('content')
    <!-- Header Section -->
    <div class="relative h-60 mb-10">
        <div class="absolute inset-0 bg-[url('/image/10.jpg')] bg-cover bg-center"></div>
        <div class="absolute inset-0 bg-black opacity-50"></div>
        <div class="relative flex items-center justify-center h-full">
            <h1 class="font-bold text-[50px] text-white tracking-wider uppercase">{{ $_service->name }}</h1>
        </div>
    </div>

    <!-- Content Section (Two Columns) -->
    <div class="max-w-6xl mx-auto px-4">
        <div class="flex flex-col lg:flex-row gap-8">


            <!-- Left: Service Detail -->
            <!-- Service Detail Section -->
            <div class="max-w-6xl mx-auto mt-8 p-4">
                <div class="bg-white rounded-xl shadow-2xl p-8 flex flex-wrap lg:flex-nowrap gap-8">

                    <!-- Left: Text Content -->
                    <div class="w-full lg:w-2/3 space-y-6">
                        <div class="border-l-4 border-blue-900 pl-6">
                            <h2 class="text-4xl font-bold text-[#1a3c77] leading-tight">{{ $_service->name }}</h2>
                        </div>

                        <div class="text-gray-700 text-lg leading-relaxed">
                            @if (!empty($_service->excerpt))
                                {!! $_service->excerpt !!}
                            @else
                                <p>No description available.</p>
                            @endif
                        </div>
                    </div>

                    <!-- Right: Image -->
                    <div class="w-full lg:w-1/3">
                        @if (isset($_service->photo))
                            <div class="relative w-full h-[250px] overflow-hidden rounded-xl shadow-lg">
                                <img src="{{ $_service->image_path_withAsset() }}" alt="{{ $_service->name }}"
                                    class="w-full h-full object-cover transition-transform duration-500 ease-in-out">
                                <div
                                    class="absolute top-2 left-2 bg-blue-900 text-white text-xs px-3 py-1 rounded-full shadow">
                                    Featured
                                </div>
                            </div>
                        @endif
                    </div>

                </div>
            </div>

            <!-- Right: Related Services -->
            <div class="lg:w-1/3 bg-white rounded-xl shadow-md p-6 h-fit">
                <h2 class="text-2xl font-bold text-[#1a3c77] mb-4 border-b-2 border-blue-900 pb-2">
                    Related Services
                </h2>

                <ul class="list-disc pl-5 space-y-2 text-[#1a3c77]">
                    @forelse ($all_service as $service)
                        <li>
                            <a href="{{ route('serviceDetail', $service->slug) }}" class="hover:underline">
                                {{ \Illuminate\Support\Str::limit($service->name, 50) }}
                            </a>
                        </li>
                    @empty
                        <li class="text-gray-500">No related services found.</li>
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
@endsection
