@extends('admin.layout.frame')

@section('content')
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Dashboard</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item active">
                                <a href="{{ route('home') }}">Home</a>
                            </li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">{{ __('Dashboard') }}</div>

                            <div class="card-body">
                                @if (session('status'))
                                    <div class="alert alert-success" role="alert">
                                        {{ session('status') }}
                                    </div>
                                @endif

                                {{ __('You are logged in!') }}
                            </div>
                        </div>
                        <div class="card">


                            <div class="card-header">Contact Form List</div>
                            <div class="card-body">
                                @include('admin.layout.pagination')


                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>SN</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Subject</th>
                                            <th>Message</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="ui-sortable">
                                        @if (isset($data['res']) && $data['res']->count() >= 0)
                                            @foreach ($data['res'] as $key => $row)
                                                <tr class="ui-sortable-handle">
                                                    <td class="center">
                                                        <label class="pos-rel">
                                                            <input type="hidden" name="ids[]"
                                                                value="{{ $row->id }}">
                                                            <input type="checkbox" class="ace" />
                                                            <span class="lbl"></span>
                                                        </label>
                                                    </td>
                                                    <td>{{ $key + 1 }}</td>
                                                    <td>
                                                        {{ $row->name }}
                                                    </td>
                                                    <td>{{ $row->email }}</td>
                                                    <td>{{ $row->subject }}</td>
                                                    <td>{{ $row->message }}</td>

                                                    <td>
                                                        {{-- @can(lcfirst($_panel) . '-edit')
                                                <a href="{{ route($_base_route . '.edit', $row->id) }}"
                                                    class="btn btn-sm btn-success">
                                                    Edit
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                            @endcan --}}
                                                        @can(lcfirst($_panel) . '-delete')
                                                            <a href="javascript:void(0)"
                                                                onclick="var c = confirm('{{ 'Are you sure?' }}'); if(c){document.getElementById('delete-{{ $row->id }}').submit();}"
                                                                class="btn btn-sm swalDefaultQuestion btn-danger">
                                                                Delete
                                                                <i class="fa fa-trash"></i>
                                                            </a>
                                                        @endcan
                                                    </td>
                                                </tr>
                                            @endforeach
                                        @endif
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th></th>
                                            <th>SN</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Subject</th>
                                            <th>Message</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                </table>

                                {!! Form::close() !!}
                                @if (isset($data['res']) && $data['res']->count() >= 0)
                                    @foreach ($data['res'] as $key => $row)
                                        <form id="delete-{{ $row->id }}"
                                            action="{{ route('admin.contact.destroy', $row->id) }}" method="POST"
                                            style="display: none;">
                                            @method('DELETE')
                                            @csrf
                                        </form>
                                    @endforeach
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- /.content -->



    </div>
@endsection
@section('title', 'Dashboard')
